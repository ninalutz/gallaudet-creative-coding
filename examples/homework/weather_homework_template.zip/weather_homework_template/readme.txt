Instructions 
Goal: Edit sketch.js and draw your own weather drawing from the get requests listed on the website 

1. First, pick a location and find its lat and lon in google maps
2. Pick the weather measurement(s) you want and find their get reqeusts -- the GET requests supported are available at this link: http://ninalutz.github.io/gallaudet-creative-coding/GetFunctionsWeather.pdf
3. Draw these weather measurement(s) 
4. Iterate twice by copying your entire weather_homework_template 2 times -- naming it [YOURNAME]_weather_homework_1, [YOURNAME]_weather_homework_2, [YOURNAME]_weather_homework_3 
5. At the end you should have 3 separate files that are different from your iterations
6. Don't forget to take screenshots! :) 

