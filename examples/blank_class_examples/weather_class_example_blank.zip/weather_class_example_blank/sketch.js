//TODO: Replace these with the location you want using Google maps
var lat = 38.9072;
var lon = -77.0369;

//location for our weather ellipse
var locY;
var locX;
var direction = 1;

function setup() {
  createCanvas(375, 667);

}

function draw(){

}